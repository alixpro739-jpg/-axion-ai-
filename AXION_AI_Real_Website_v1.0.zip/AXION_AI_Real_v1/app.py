import os, sqlite3, secrets, time
from functools import wraps
from flask import Flask, request, jsonify, session, send_from_directory
import requests
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "axion.db")
app = Flask(__name__, static_folder="static")
app.secret_key = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=1 * 1024 * 1024,
)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at INTEGER NOT NULL
        )""")

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return jsonify({"error": "برای ادامه وارد حساب شو."}), 401
        return fn(*args, **kwargs)
    return wrapper

@app.get("/")
def home():
    return send_from_directory(app.static_folder, "index.html")

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "service": "AXION AI", "version": "1.0",
                    "ai_configured": bool(os.environ.get("OPENAI_API_KEY"))})

@app.post("/api/signup")
def signup():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    if len(email) > 254 or "@" not in email or "." not in email.split("@")[-1]:
        return jsonify({"error": "ایمیل معتبر وارد کن."}), 400
    if len(password) < 8:
        return jsonify({"error": "رمز عبور باید حداقل ۸ کاراکتر باشد."}), 400
    try:
        with db() as con:
            cur = con.execute("INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)",
                              (email, generate_password_hash(password), int(time.time())))
            uid = cur.lastrowid
        session.clear()
        session["user_id"] = uid
        session["email"] = email
        return jsonify({"ok": True, "email": email})
    except sqlite3.IntegrityError:
        return jsonify({"error": "این ایمیل قبلاً ثبت شده؛ وارد حساب شو."}), 409

@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    with db() as con:
        user = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not user or not check_password_hash(user["password_hash"], password):
        return jsonify({"error": "ایمیل یا رمز عبور اشتباه است."}), 401
    session.clear()
    session["user_id"] = user["id"]
    session["email"] = user["email"]
    return jsonify({"ok": True, "email": user["email"]})

@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})

@app.get("/api/me")
def me():
    if session.get("user_id"):
        return jsonify({"logged_in": True, "email": session.get("email")})
    return jsonify({"logged_in": False})

@app.post("/api/chat")
@login_required
def chat():
    data = request.get_json(silent=True) or {}
    messages = data.get("messages")
    if not isinstance(messages, list) or not messages:
        return jsonify({"error": "پیامی برای ارسال وجود ندارد."}), 400
    clean = []
    for item in messages[-16:]:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        content = item.get("content")
        if role not in ("user", "assistant") or not isinstance(content, str):
            continue
        content = content.strip()[:6000]
        if content:
            clean.append({"role": role, "content": content})
    if not clean or clean[-1]["role"] != "user":
        return jsonify({"error": "آخرین پیام باید پیام شما باشد."}), 400

    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        return jsonify({"error": "اتصال هوش مصنوعی هنوز تنظیم نشده است. مدیر سایت باید OPENAI_API_KEY را روی سرور تنظیم کند."}), 503
    base_url = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "You are AXION AI, a helpful, friendly assistant. Reply in the same language as the user unless asked otherwise. Be clear and honest."},
            *clean
        ],
        "temperature": 0.7
    }
    try:
        r = requests.post(base_url + "/chat/completions",
                          headers={"Authorization": "Bearer " + api_key,
                                   "Content-Type": "application/json"},
                          json=payload, timeout=90)
        if not r.ok:
            # Do not leak provider response bodies, keys, or infrastructure details to users.
            app.logger.warning("AI provider returned HTTP %s", r.status_code)
            return jsonify({"error": "سرویس هوش مصنوعی پاسخ نداد. تنظیمات مدل و اعتبار API را بررسی کن."}), 502
        result = r.json()
        answer = result["choices"][0]["message"]["content"]
        if not isinstance(answer, str) or not answer.strip():
            raise ValueError("Empty AI response")
        return jsonify({"reply": answer.strip(), "model": model})
    except requests.Timeout:
        return jsonify({"error": "پاسخ‌گویی طول کشید؛ دوباره امتحان کن."}), 504
    except Exception:
        app.logger.exception("AI request failed")
        return jsonify({"error": "فعلاً پاسخ دریافت نشد. اتصال سرویس را بررسی کن."}), 502

init_db()

if __name__ == "__main__":
    # Local development only. Use a production WSGI server when deploying.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
